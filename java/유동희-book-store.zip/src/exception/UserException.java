package exception;

@SuppressWarnings("serial")
public class UserException extends BookStoreException {

	public UserException(String message) {
		super(message);
	}
}
