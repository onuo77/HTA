package step3;

import java.util.Scanner;

public class App6 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int[] numbers = new int[5];
		
		/*
		 * 일반 for문을 이용해서 키보드 입력을 받아서 배열에 순서대로 저장하세요
		 * 배열에 저장된 값의 합계를 계산해서 화면에 출력하시오
		 */
	}
}
