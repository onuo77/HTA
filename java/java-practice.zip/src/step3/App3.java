package step3;

public class App3 {

	public static void main(String[] args) {
		/*
		 * 정수형 배열객체에 저장된 값들을 향상된 for문을 사용해서 출력하시오
		 */
		int[] numbers = {100, 200, 300, 400, 500};
	}
}
