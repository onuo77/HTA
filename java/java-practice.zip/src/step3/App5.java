package step3;

import java.util.Scanner;

public class App5 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int[] numbers = new int[5];
		
		/*
		 * 일반 for문을 이용해서 키보드 입력을 받아서 배열에 순서대로 저장하세요
		 * - for문내의 수행문은 5번 실행되도록 한다.
		 * - 수행문 
		 * 	- Scanner객체의 nextInt()을 사용해서 정수를 입력받는다.
		 * 	- 배열에 순서대로 입력받은 값을 저장한다.
		 * 배열객체에 저장된 값을 향상된 for문을 이용해서 출력하세요
		 */
	}
}
