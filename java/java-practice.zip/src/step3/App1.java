package step3;

public class App1 {

	public static void main(String[] args) {
		/*
		 * 정수배열객체에 저장된 값을 모두 출력하시오
		 */
		int[] numbers = {10, 30, 50, 70, 100};
		
	}
}
