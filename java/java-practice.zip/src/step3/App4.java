package step3;

public class App4 {

	public static void main(String[] args) {
		/*
		 * 정수 5개를 저장할 수 있는 정수형배열객체를 생성하세요.
		 * 정수형배열객체의 0번째, 1번째, 2번째, 3번째, 4번째 위치에 100, 200, 300, 400, 500을 저장하시오
		 * 정수형배열객체에 저장된 값들을 향상된 for문을 사용해서 출력하시오
		 */
	}
}
