package step6;

public class App2 {

	public static void main(String[] args) {
		/*
		 * Order객체를 여러개 저장할 수 있는 ArrayList객체를 생성하시오.
		 * 
		 * Order객체를 생성하시오.
		 * setter 메소드를 이용해서 생성된 객체의 멤버변수에 주문정보를 저장하시오
		 * 생성된 Order객체를 ArrayList객체에 추가하시오.
		 * 
		 * Order객체를 생성하시오.
		 * setter 메소드를 이용해서 생성된 객체의 멤버변수에 주문정보를 저장하시오
		 * 생성된 Order객체를 ArrayList객체에 추가하시오.
		 * 
		 * Order객체를 생성하시오.
		 * setter 메소드를 이용해서 생성된 객체의 멤버변수에 주문정보를 저장하시오
		 * 생성된 Order객체를 ArrayList객체에 추가하시오.
		 * 
		 * 향상된 for문을 사용해서 주문정보를 화면에 출력하시오.
		 */
	}
}
