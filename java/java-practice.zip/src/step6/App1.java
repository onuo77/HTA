package step6;

public class App1 {

	public static void main(String[] args) {
		/*
		 * 문자열을 여러개 저장할 수 있는 ArrayList객체를 생성하시오.
		 * 생성된 객체에 학생이름을 여러 개 입력해 보세요
		 * 
		 * 향상된 for문을 이용해서 ArrayList객체에 저장된 이름을 화면에 출력하세요
		 */
	}
}
