package step4;

public class App4 {

	public static void main(String[] args) {
		/*
		 * StudentScore.java 클래스에 생성된 객체의 멤버변수에 저장된 학생이름, 국어점수, 영어점수, 수학점수, 총점, 평균을 출력하는 메소드를 추가하세요
		 * 메소드 선언부는 public void printInfo() { 수행문 추가 }
		 * 
		 * StudentScore객체를 생성하고, 학생이름, 국어점수, 영어점수, 수학점수를 멤버변수에 대입하세요.
		 * 위에서 정의한 메소드를 실행해서 학생성적정보를 화면에 출력하시오
		 */
	}
}
