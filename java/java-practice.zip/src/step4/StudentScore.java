package step4;

public class StudentScore {

	String name;
	int kor;
	int eng;
	int math;
}
