package step5;

public class App2 {

	public static void main(String[] args) {
		/*
		 * Product.java에 상품정보를 화면에 출력하는 public void displayProductInfo() 메소드를 추가하시오.
		 * 
		 * Product객체를 생성하세요. 기본생성자를 사용하세요.
		 * Product객체를 생성하세요. 모든 멤버변수를 초기화하는 생성자를 사용하세요
		 * 
		 * 생성된 객체의 displayProductInfo() 메소드를 생성해서 생성된 객체의 정보를 출력하시오
		 */
	}
}
