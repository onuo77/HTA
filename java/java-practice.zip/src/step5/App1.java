package step5;

public class App1 {

	public static void main(String[] args) {
		
		/*
		 * Product.java 클래스에 기본 생성자를 추가하시오.
		 * Product.java 클래스에 모든 멤버변수를 초기화하는 생성자를 추가하시오.
		 * 
		 * Product객체를 생성하시오. 기본생성자를 활용하세요
		 * Product객체를 생성하시오. 모든 멤버변수를 초기화하는 생성자를 활용하세요
		 */
	}
}
