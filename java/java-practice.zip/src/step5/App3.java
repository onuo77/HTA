package step5;

public class App3 {

	public static void main(String[] args) {
		/*
		 * Product.java 클래스에 getter/setter 메소드를 추가하시오
		 * 
		 * Product객체를 생성하시오. 기본생성자를 사용하세요.
		 * setter 메소드를 이용해서 상품명, 제조사, 가격, 재고량을 멤벼변수에 대입하시오.
		 * 
		 * 생성된 Product객체의 멤버변수에 저장된 상품정보를 getter 메소드를 이용해서 조회해서 화면에 출력하시오
		 */
	}
}
