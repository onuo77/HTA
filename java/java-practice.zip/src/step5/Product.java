package step5;

public class Product {

	private String name;
	private String company;
	private int price;
	private int stock;
	
}
