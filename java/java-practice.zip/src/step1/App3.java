package step1;

public class App3 {

	public static void main(String[] args) {
		/*
		 * 정수 10과 정수 20을 담는 변수를 정의하고, 변수에 값을 대입하세요.
		 * 각각의 변수에 저장된 값을 덧셈한 결과를 새로운 변수에 대입하세요
		 * 위에서 정의한 모든 변수에 저장된 값을 화면에 출력하시오
		 */
	}
}
