package step1;

public class App2 {

	public static void main(String[] args) {
		/*
		 * 정수 10
		 * 실수 3.14
		 * 문자 'S'
		 * 논리값 true
		 * 문자열 "안녕하세요"
		 * 
		 * 위에 제시된 값을 담는 적절한 변수를 정의하고, 변수에 위의 값을 대입하세요
		 * 변수에 대입된 값을 화면에 출력하세요
		 */
	}
}
