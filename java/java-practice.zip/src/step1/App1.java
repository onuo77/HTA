package step1;

public class App1 {

	/*
	 * main 메소드를 정의하고, 임의의 문자열 출력하시오
	 */
}
