package step2;

public class App2 {

	public static void main(String[] args) {
		/*
		 * for문을 이용해서 1~10까지 화면에 출력하세요
		 */
	}
}
