package exception;

@SuppressWarnings("serial")
public class BookException extends BookStoreException {

	public BookException(String message) {
		super(message);
	}
}
